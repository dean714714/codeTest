<template>
	<div class="list-block">
		<router-view :fontCards="[]"></router-view>
		<ul>
			<li @click="actionInfo('请前往【我的】页面进行实名认证~')">
				<a href="#" class="item-link item-content">
					<div class="item-inner borderB">
						<div class="item-title">市民卡</div>
						<div class="item-after"></div>
					</div>
				</a>
			</li>
			<li @click="$router.replace({ path: '/add_cards_ls/add_fjmk' })">
				<a href="#" class="item-link item-content">
					<div class="item-inner">
						<div class="item-title">杭州通卡/公交卡</div>
						<div class="item-after"></div>
					</div>
				</a>
			</li>
		</ul>
	</div>
</template>

<script>
	export default {
		data: function(){
			return {
				f7: {},
			}
		},
		mounted: function(){
			this.f7 = new Framework7();
		},
		methods: {
			actionInfo: function(info){
				this.f7.alert(info, '', function () {
			       
			    })
			}
		}
	}
</script>

<style scoped>
	.list-block{
		margin: 1.5rem 0;
	}
	.list-block ul::after,.list-block ul::before{
		display: none;
	}
	.list-block .item-inner::after{
		display: none;
	}
	.item-title{
		font-size: 1.7rem;
		color: #333;
	}
</style>