<template>
	<div>
		弹出层
	</div>
</template>

<script>
	export default {
		name: 'alertInfo',
		props: ['info'],
		data: function(){
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped>
	
</style>