<template>
	<div :class="[chartClass]" :style="{height:chartHeight}"></div>
</template>

<script>
	// 引入基本模板
	let echarts = require('echarts/lib/echarts')
	// 引入折线图组件
	require('echarts/lib/chart/line')
	// 引入提示框和title组件
	require('echarts/lib/component/tooltip')
	require('echarts/lib/component/title')
	require('echarts/lib/component/visualMap')
	require('echarts/lib/component/legend')
	
	export default {
		name: 'chartComfort',
		props: ['chartData','chartClass','chartHeight'],
		data() {
			return {
				valueY: [],
				busyDeg: [],
				axisY:['00:00','00:30','01:00','01:30','02:00','02:30','03:00','03:30','04:00','04:30','05:00','05:30','06:00','06:30','07:00','07:30','08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00','23:30','24:00'],
			}
		},
		computed: {
			nowTime: function(){
				var _this = this,
				_date = new Date(),
				hours = '',
				mint = _date.getMinutes();
				if(mint>=30){
					_date.setMinutes(_date.getMinutes()+30);
					hours = (function(){
						if(_date.getHours()<10){
							return '0'+_date.getHours();
						}else{
							return ''+_date.getHours();
						}
					})();
					mint = '00'
				}else{
					hours = (function(){
						if(_date.getHours()<10){
							return '0'+_date.getHours();
						}else{
							return ''+_date.getHours();
						}
					})();
					mint = '30'
				}
				
				var time = hours+":"+mint;
				var index = (function(){
					var i;
					_this.axisY.map(function(value,index){
						if(value===time){
							console.log(index);
							i = index;
						}
					})
					return i;
				})()
				//console.log(index)
				return {index: index,time: time};
			}
		},
		mounted: function(){
			//this.drawLine();//若此时绘制，那watch高度传过来的时候将无法再次绘制，会提示已经实例化
		},
		methods: {
			drawLine() {
			  var _this=this;
		      // 基于准备好的dom，初始化echarts实例
		      var chartDom = document.querySelector('.'+this.chartClass);
		      chartDom.style.height = this.chartHeight;
		      //console.log(chartDom)
		      let myChart = echarts.init(chartDom);
		      // 绘制图表
		      myChart.setOption({
		      	title: {
		      		show: false,
			        text: 'XX折线图',
			    },
			    tooltip: {
			        trigger: 'axis',
			        formatter: function(params, ticket, callback){
			        	var value = params[0].value,xVal = params[0].axisValue,dotColor=params[0].color;
						var index = (function(){
							var i;
							_this.axisY.map(function(value,index){
								if(value===xVal){
									//console.log(index)
									i = index;
								}
							})
							return i;
						})();
						//value = index;
						value = (function(){
							var deg = _this.busyDeg[index];
				        	if(deg===0){
				        		return '非常舒适';
				        	}else if(deg===1){
				        		return '舒适';
				        	}else if(deg===2){
				        		return '轻度拥挤';
				        	}else if(deg===3){
				        		return '拥挤';
				        	}else if(deg===4){
				        		return '重度拥挤';
				        	}
						})();
						_this.$emit("getComfortDeg",value);
			        	var temp = xVal+'时'+'<br/><span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:'+dotColor+';"></span>繁忙度: '+value;
			        	return temp;
			        }
			    },
			    legend: {
			    	show: true,
			    	type: 'plain',
			    	top: 'auto',
			    	left: 10,
			    	bottom: 0,
			    	orient: 'vertical',
			        data:[{
			        	name:'a',
			        	icon: 'circle',
					    // 设置文本为红色
					    textStyle: {
					        color: 'red'
					    }
					}]
				},
			    grid: {
			        left: '0%',
			        right: '0%',
			        bottom: '20%',
			        top: '0%',
			        containLabel: false
			    },
			    color: ['#4a90e2'],
			    xAxis: {
			        type: 'category',
			        boundaryGap: true,
			        axisLine: {
			        	lineStyle: {
			        		color: '#666',
			        	}
			        },
			        axisTick: {
			        	show: true,
			        	interval: 0,//强制显示所有刻度
			        	length:0,
			        	lineStyle: {
			        		
			        	}
			        },
		        	axisLabel: {
		        		interval: 5,//强制显示所有刻度标签
		        		formatter: '{value}',
		        		fontSize: 8
		        	},
		        	splitLine: {
		        		show: true,//是否显示纵向分割线，y轴默认显示，x轴默认不现实
		        		lineStyle: {
		        			color: ['#dedede'],
		        			width: 0.5,
		        			type: 'solid'
		        		}
		        	},
		        	splitArea: {
		        		show: false,//类目轴有效，用色块分割
		        	},
		        	axisPointer: {
		        		show: true,
		        		type: 'line',
		        		lineStyle: {
		        			color: {
							    type: 'linear',
							    x: 0,
							    y: 0,
							    x2: 0,
							    y2: 1,
							    colorStops: [{
							        offset: 0, color: 'rgba(0,0,0,0.8)' // 0% 处的颜色
							    }, {
							        offset: 1, color: 'rgba(0,0,0,0.8)' // 100% 处的颜色
							    }],
							    globalCoord: false // 缺省为 false
							}
		        		},
		        		handle: {//拖拽手柄，适用于触屏环境
		        			show: false
		        		}
		        	},
			        data: _this.axisY
			    },
			    yAxis: {
			    	show: true,
			        type: 'value',
			        axisLine: {
			        	show: true,//不显示轴线
			        },
			        axisTick: {
			        	show: false,
			        },
			        axisLabel: {
			        	show: false,
			        },
			        max: 125,
			        splitLine: {
		        		show: true,//是否显示纵向分割线，y轴默认显示，x轴默认不现实
		        		lineStyle: {
		        			color: ['#dedede'],
		        			width: 0.5,
		        			type: 'solid'
		        		}
		        	},
			    },
			    visualMap: {
			    	type: 'piecewise',
			    	top: 10,
		            right: 10,
		            align: 'auto',
		            orient: 'horizontal',
		            top: 'auto',
		            bottom: 0,
		            left: 0,
		            itemWidth: 12,
		            itemHeight: 12,
		            textGap:5,
		            itemGap:15,
		            textStyle: {
		            	color: '#666',
		            	fontSize: 10,
		            },
		            formatter: function(value, value2){
		            	var value2 = value2;
		            	switch (value2){
		            		case 25:
		            			return '非常舒适'
		            			break;
		            		case 50:
		            			return '舒适'
		            			break;
		            		case 75:
		            			return '轻度拥挤'
		            			break;
		            		case 100:
		            			return '拥挤'
		            			break;
		            		case 125:
		            			return '重度拥挤'
		            			break;
		            	}
		            },
		            pieces: [{
		                gte: 0,
		                lte: 25,
		                color: '#37cb19'
		            }, {
		                gt: 25,
		                lte: 50,
		                color: '#c0ab20'
		            }, {
		                gt: 50,
		                lte: 75,
		                color: '#f5a126'
		            }, {
		                gt: 75,
		                lte: 100,
		                color: '#f45659'
		            },{
		                gt: 100,
		                lte: 125,
		                color: '#d0031c'
		            }],
		            outOfRange: {
		                color: '#ccc'
		            }
			    },
			    series: [
			        {
			            name:'繁忙度',
			            type:'line',
			            stack: '总量',
			            lineStyle: {
			            	
			            },
			            data: _this.valueY,
			            //[120, 125, 101, 122, 90, 30, 110, 110, 101, 114, 10, 20, 24, 32, 101, 125, 90, 104, 110, 120, 44, 104, 90, 14,4]
			        }
			    ]
		      });
		      myChart.dispatchAction({
				type:'showTip',
				seriesIndex: 0,
				dataIndex: _this.nowTime.index
			  })
		    },
		},
		watch: {
			chartData: function(data){
				var val = [],busyDeg=[];
				data.flow.map(function(value,index){
					val.push((value.value*100).toFixed(2));
					busyDeg.push(value.busyness);
				})
				//console.log(val);
				this.valueY = val;
				this.busyDeg = busyDeg;
				this.drawLine();
			},
			chartHeight: function(val){
				//console.log(val)
				this.drawLine();
			}
		}
	}
</script>

<style>
</style>