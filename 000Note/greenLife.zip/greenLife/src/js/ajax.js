
function getData(url,rqType,para,callback){//获取数据
	//加载提示
	var $load = document.createElement('div');
	$load.innerHTML = "加载中，请稍后...";
	$load.style.cssText = "width:160px;line-height:60px;text-align:center;color:#fff;background:#000;position: fixed;left: 50%;top: 50%;margin: -40px 0 0 -80px;z-index:100;border-radius: 10px;"
	document.body.appendChild($load);
	jQuery.support.cors=true;//ie8,9不支持服务器端设置CORS,加这句就行
	$.ajax({
		type:rqType,
		url:url,
		async:true,
		dataType:'json',
		data:para,
		success:function(data){
			if(data.code==='103'){//系统出错处理机制
				var $div = document.createElement('div');
				$div.innerHTML = "系统内部出错，请刷新或稍后重试~";
				$div.style.cssText = "font-size: 24px;font-weight: bold;letter-spacing: 4px;color: #ccc;font-style: italic;display: block;text-align: center;margin: 100px auto;"
				document.body.innerHTML = "";
				document.body.appendChild($div);
				return;
			}
			callback(data);
			$load.parentNode.removeChild($load);//关闭加载提示
		},
		error:function(a){
			console.log(a)
			//$load.parentNode.removeChild($load);//关闭加载提示
			var $div = document.createElement('div');
			$div.innerHTML = "请求失败了，请刷新或稍后重试~";
			$div.style.cssText = "font-size: 24px;font-weight: bold;letter-spacing: 4px;color: #ccc;font-style: italic;display: block;text-align: center;margin: 100px auto;"
			document.body.innerHTML = "";
			document.body.appendChild($div)
		}
	});
	
}

export default {
	getData
}
