<template>
<div class="form_add">
	<div class="list-block">
		<ul>
			<li>
				<div class="item-content">
					<div class="item-inner">
						<div class="item-title label form_add_name">卡号</div>
						<div class="item-input form_add_in">
							<input type="text" placeholder="请输入杭州通卡/公交卡卡号" v-model="val">
						</div>
					</div>
					<div class="item-media" v-show="val?true:false" @click="clearVal"><i class="iconfont icon-qingchu icon_form_clear"></i></div>
				</div>
			</li>
		</ul>
	</div>
	<a href="#" class="button active btn_formAdd" @click="addCardToDB(val)">添加</a>
	<div class="action">非记名卡的添加仅用于本模块碳减排量的记录</div>
</div>
</template>

<script>
	export default {
		props: ['fontCards'],
		data() {
			return {
				val: '',
				forBack: {},
				f7: {},
				fromW: '',
			}
		},
		mounted: function(){
			this.f7 = new Framework7();	
		},
		methods: {
			clearVal: function(){
				this.val = '';
			},
			sendCardNum: function(){
				this.$emit('getCardNum',this.forBack);
				//this.$router.replace({ path: '/add_cards' });
				if(this.fromW==='/add_cards'){
					this.$router.go(-1);
				}else if(this.fromW === '/add_cards_ls'){
					this.$router.replace({ path: '/add_cards' })
				}
			},
			addCardToDB: function(value){//卡号写入数据库
				let _this = this,leg=this.fontCards.length;
				if(leg<3){
					var ifRepeat = (function(){
						var status;
						for(var i=0;i<leg;i++){
							if(_this.val===_this.fontCards[i].cardno){
								//不允许重复添加
								return true;
							}else{
								status = false;
							}
						}
						return status;
					})();
					if(ifRepeat){
						_this.f7.alert("不允许重复添加", 'STOP', function () {
					       _this.val = '';
					    })
					}else{//允许添加
						return new Promise(function(resolve){
							_this.$ajax.getData("http://192.168.23.95/ajax/relation.php",'post',{"cmd": "addex","cardno":value},resolve);
							//resolve({status:'ok'});//离线测试
						}).then(function(value){
							console.log(value)
							var status = value.status;
							if(status==='failed'){
								_this.f7.alert("卡号不存在", 'STOP', function () {
							       _this.val = '';
							    })
								console.log("卡号写入数据库失败");
							}else{
								_this.forBack = value.cards||[];
								_this.sendCardNum();
								console.log("卡号写入数据库成功");
							}
							return status;
						})
					}
				}else{
					_this.f7.alert("最多添加三张", 'STOP', function () {
				       _this.val = '';
				    })
				}
				
			},
		},
		beforeRouteEnter (to, from, next) {
			next(function(vm){//next回调才行，不然此时尚未实例化故而获取不到this
				vm.fromW = from.path;
			})
		},
//		beforeRouteLeave (to, from, next) {
//			if(this.fromW==='/add_cards'){
//				this.$router.go(-1);
//			}else if(this.fromW === '/add_cards_ls'){
//				this.$router.replace({ path: '/add_cards' })
//			}
//		},
		
	}
</script>

<style scoped>
	.list-block{
		margin:1.5rem 0;
	}
	.list-block ul::before,.list-block ul::after{
		display: none;
	}
	.form_add{
		position: fixed;
		z-index: 100;
		left: 0;
		top: 0;
		width: 100vw;
		height: 100vh;
		background: #f5f5f9;
	}
	.form_add_name{
		width: auto !important;
		font-size: 1.7rem;
	}
	.form_add_in{
		margin-left: 2rem !important;
	}
	.list-block input[type="date"], .list-block input[type="datetime-local"], .list-block input[type="email"], .list-block input[type="number"], .list-block input[type="password"], .list-block input[type="search"], .list-block input[type="tel"], .list-block input[type="text"], .list-block input[type="time"], .list-block input[type="url"], .list-block select, .list-block textarea{
		font-size: 1.7rem;
	}
	.form_add_in input{
		font-size: 1.7rem !important;
	}
	.icon_form_clear{
		font-size: 1.4rem;
		color: #DEDEDE;
		margin-right: 1.5rem;
	}
	.button.active{
		background: #289e25;
	}
	.btn_formAdd{
		line-height: 4.4rem;
		height: 4.4rem;
		margin: 3rem 1.5rem 1rem 1.5rem;
		background: #289e25;
		border: none;
		font-size: 1.8rem;
	}
</style>