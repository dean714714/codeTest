<template>
	<div class="trafficBox">
		<router-view :tabActive="tabActive" @updateHis="updateHis" @updateTag="updateTag"></router-view>
		<!--updateTag 解决返回时tab标签选中类active不显示的问题-->
		<div class="tabBox">
			<div class="buttons-row btnBox">
				<!-- 关联到第一个tab的链接，默认激活 -->
				<a href="#tab1" class="tab-link button" :class="{active: tabActive}" @click="tabActive=true"><span>公交</span></a>
				<!-- 关联到第二个tab的链接 -->
				<a href="#tab2" class="tab-link button" :class="{active: !tabActive}" @click="tabActive=false"><span>地铁</span></a>
			</div>
			<div class="row" style="padding: 0 1.5rem; margin-top: 2.5rem;" v-show="tabActive">
			    <div class="col-85" style="width: 86.7%;">
			    	<div class="searchIn">
			    		<i class="iconfont icon-sousuo"></i>
			    		<input type="text" class="navSearch_in" placeholder="请输入公交线路名称" v-on:focus="$router.push({ path: '/traffic/traffic_ls' })">
			    	</div>
			    </div>
			    <div class="" style="width: 12%;">
			    	<div class="btn_navSearch">搜索</div>
			    </div>
			</div>
			<div class="row" style="padding: 0 1.5rem; margin-top: 2.5rem;" v-show="!tabActive">
			    <div class="col-85" style="width: 86.7%;">
			    	<div class="searchIn">
			    		<i class="iconfont icon-sousuo"></i>
			    		<input type="text" class="navSearch_in" placeholder="请输入地铁站点名称" v-on:focus="$router.push({ path: '/traffic/traffic_ls' })">
			    	</div>
			    </div>
			    <div class="" style="width: 12%;">
			    	<div class="btn_navSearch">搜索</div>
			    </div>
			</div>
		</div>
		<div class="tabs-animated-wrap" style="height: 50vh;">
			<div class="tabs" :style="{transform: transformSty}">
				<!-- Tab 1，默认激活 -->
				<div id="tab1" class="tab" :class="{active: tabActive}">
					<div class="swiper-custom" style=" margin-top: 3rem;"><!--日期swiper-->
						<div class="swiper-container">
						  <div class="swiper-pagination"></div>
						  <div class="swiper-wrapper">
						    <div class="swiper-slide" ref="historyGj_slide">
						    	<div class="searchTs">
						    		<div class="searchTs_t borderB">关注线路</div>
						    		<div class="searchTs_l borderB"  v-for="item in historyGj" @click="storeHistory(item.name,item.lineno,'lineno');$router.push({ path: '/traffic/comfort', query: { code: item.lineno,name: item.name}})">
						    			<div class="searchTs_tag st_c_yj" :style="{background:!isNaN(item.busyness)?busyDegMap[item.busyness].color:'#dedede'}">{{!isNaN(item.busyness)?busyDegMap[item.busyness].des:'--'}}</div>
						    			{{item.name}}路
						    		</div>
						    	</div>
						    </div>
						    <div class="swiper-slide">
						    	<div class="searchTs">
						    		<div class="searchTs_t borderB">常乘坐线路</div>
						    		<div class="searchTs_l borderB" v-for="item in commonLineGj" @click="storeHistory(item.name,item.lineno,'lineno');$router.push({ path: '/traffic/comfort', query: { code: item.lineno,name: item.name}})">
						    			<div class="searchTs_tag st_c_yj" :style="{background:!isNaN(item.busyness)?busyDegMap[item.busyness].color:'#dedede'}">{{!isNaN(item.busyness)?busyDegMap[item.busyness].des:'--'}}</div>
						    			{{item.name}}路
						    		</div>
						    	</div>
						    </div>
						   <div class="swiper-slide">
						    	<div class="searchTs">
						    		<div class="searchTs_t borderB">当前繁忙线路</div>
						    		<div class="searchTs_l borderB" v-for="(value,key) in busyLineGj" @click="storeHistory(value.name,value.lineno,'lineno');$router.push({ path: '/traffic/comfort', query: { code: value.lineno,name: value.name}})">
						    			<div class="searchTs_tag st_c_top1" :class="['st_c_top'+(key+1)]">Top{{key+1}}</div>
						    			{{value.name}}路<!--st_c_top1-->
						    		</div>
						    	</div>
						    </div>
						  </div>
						</div>
					</div>
				</div>
				<!-- Tab 2 -->
				<div id="tab2" class="tab" :class="{active: !tabActive}">
					<div class="swiper-custom" style=" margin-top: 3rem;"><!--日期swiper-->
						<div class="swiper-container">
						  <div class="swiper-pagination"></div>
						  <div class="swiper-wrapper">
						    <div class="swiper-slide" ref="historyDt_slide">
						    	<div class="searchTs">
						    		<div class="searchTs_t borderB">关注站点</div>
						    		<div class="searchTs_l borderB"  v-for="item in historyDt" @click="storeHistory(item.name,item.stationno,'stationno');$router.push({ path: '/traffic/comfort_dt', query: { code: item.stationno,name: item.name}})">
						    			<div class="searchTs_tag st_c_yj" :style="{background:!isNaN(item.busyness)?busyDegMap[item.busyness].color:'#dedede'}">{{!isNaN(item.busyness)?busyDegMap[item.busyness].des:'--'}}</div>
						    			{{item.name}}
						    		</div>
						    	</div>
						    </div>
						    <div class="swiper-slide">
						    	<div class="searchTs">
						    		<div class="searchTs_t borderB">常乘坐站点</div>
						    		<div class="searchTs_l borderB" v-for="item in commonLineDt" @click="storeHistory(item.name,item.stationno,'stationno');$router.push({ path: '/traffic/comfort_dt', query: { code: item.stationno,name: item.name}})">
						    			<div class="searchTs_tag st_c_yj" :style="{background:!isNaN(item.busyness)?busyDegMap[item.busyness].color:'#dedede'}">{{!isNaN(item.busyness)?busyDegMap[item.busyness].des:'--'}}</div>
						    			{{item.name}}
						    		</div>
						    	</div>
						    </div>
						   <div class="swiper-slide">
						    	<div class="searchTs">
						    		<div class="searchTs_t borderB">当前繁忙站点</div>
						    		<div class="searchTs_l borderB" v-for="(value,key) in busyLineDt" @click="storeHistory(value.name,value.lineno,'stationno');$router.push({ path: '/traffic/comfort_dt', query: { code: value.lineno,name: value.name}})">
						    			<div class="searchTs_tag st_c_top1" :class="['st_c_top'+(key+1)]">Top{{key+1}}</div>
						    			{{value.name}}<!--st_c_top1-->
						    		</div>
						    	</div>
						    </div>
						  </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	
	export default {
		data () {
			return {
				tabActive: true,
				busyLineGj: [],
				commonLineGj: [],
				historyGj: [],
				busyLineDt: [],
				commonLineDt: [],
				historyDt: [],
				//commonLineBusyDegGj: [],
				busyDegMap: [
					{busyness:0,des:'非常舒适',color:"#3ad41a"},
					{busyness:1,des:'舒适',color:"#31b716"},
					{busyness:2,des:'轻度拥挤',color:"#f5a623"},
					{busyness:3,des:'拥挤',color:"#f75c5d"},
					{busyness:4,des:'重度拥挤',color:"#d0021b"}
				],
					
				
			}
		},
		computed: {
			transformSty: function(){
				var arr = ['translate3d(-100%, 0px, 0px)','translate3d(0%, 0px, 0px)'];
				if(this.tabActive){
					return arr[1];
				}else{
					return arr[0];
				}
			},
//			commonLineGjArr: function(){
//				var _this = this;
//				this.commonLineGj.map(function(value,index){
//					value.busyness = _this.commonLineBusyDegGj[index];
//				})
//				return this.commonLineGj
//			}
		},
		mounted: function(){
			var swiper = this.mySwiper(),_this=this;
			this.getBusyGj('top4');
			this.getCommonGj('common');
			this.getHistoryGj();
			this.getBusyDt('top4');
			this.getCommonDt('common');
			this.getHistoryDt();
			//swiper[0].update();
//			if(this.historyGj.length===0){
//				swiper[0].removeSlide(0);
//			}
//			if(this.historyDt.length===0){
//				swiper[1].removeSlide(0);
//			}
		},
		methods: {
			getBusyGj: function(cmd){//公交繁忙top4
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/busline.php','post',{'cmd': cmd},function(data){
					if(data.status==='ok'){
						var result = data.result;
						result.splice(3,result.length);//只保留前三条
						_this.busyLineGj = result;
					}else{
						console.log(data);
					}
				});
			},
			getHistoryGj: function(){//公交历史纪录
				var _this = this;
				var historyGj = JSON.parse(localStorage.getItem('lineno'))||[];
				historyGj.splice(3,historyGj.length);//只保留前三条
				this.getBusyDegGj('busy',(function(){
					var arr=[];
					historyGj.map(function(value,index){
						arr.push(value.lineno);
					})
					return arr;
				})(),function(data){
					if(data.status==='ok'&&data.result.length===historyGj.length){
						data.result.map(function(value,index){
							historyGj[index].busyness = value.busyness;
						})
					}else{
						console.log("公交历史纪录，繁忙程度获取失败："+data)
					}
					_this.historyGj = historyGj;
				})
			},
			getCommonGj: function(cmd){//常乘坐公交线路
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/busline.php','post',{'cmd': cmd},function(data){
					if(data.status==='ok'){
						//_this.commonLineGj = data.result.line;
						var clArr = data.result.line;
						clArr.splice(3,clArr.length);
						_this.getBusyDegGj('busy',(function(){
							var arr=[];
							clArr.map(function(value,index){
								arr.push(value.lineno);
							})
							return arr;
						})(),function(data){
							if(data.status==='ok'&&data.result.length===clArr.length){
								data.result.map(function(value,index){
									clArr[index].busyness = value.busyness;
								})
							}else{
								console.log("常乘坐线路，获取线路繁忙程度失败："+data)
							}
							_this.commonLineGj = clArr;
						})
					}else{
						console.log(data);
					}
				});
			},
			getBusyDegGj: function(cmd,linenos,callback){//查询公交繁忙程度
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/busline.php','post',{'cmd': cmd,'linenos': linenos},function(data){
					callback(data);
				});
			},
			getBusyDt: function(cmd){//地铁繁忙top4
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/metrostation.php','post',{'cmd': cmd},function(data){
					if(data.status==='ok'){
						var result = data.result;
						result.splice(3,result.length);//只保留前三条
						_this.busyLineDt = result;
					}else{
						console.log(data);
					}
				});
			},
			getHistoryDt: function(){//地铁历史纪录
				var _this = this;
				var historyDt = JSON.parse(localStorage.getItem('stationno'))||[];
				historyDt.splice(3,historyDt.length);//只保留前三条
				this.getBusyDegDt('busy',(function(){
					var arr=[];
					historyDt.map(function(value,index){
						arr.push(value.stationno);
					})
					return arr;
				})(),function(data){
					console.log(data)
					if(data.status==='ok'&&data.result.length===historyDt.length){
						data.result.map(function(value,index){
							historyDt[index].busyness = value.busyness;
						})
					}else{
						console.log("常搜索站点，获取地铁繁忙程度失败："+data)
					}
					_this.historyDt = historyDt;
				})
			},
			getCommonDt: function(cmd){//常乘坐地铁线路
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/metrostation.php','post',{'cmd': cmd},function(data){
					if(data.status==='ok'){
						var clArr = data.result.line;
						clArr.splice(3,clArr.length);
						_this.getBusyDegDt('busy',(function(){
							var arr=[];
							clArr.map(function(value,index){
								arr.push(value.stationno);
							})
							return arr;
						})(),function(data){
							if(data.status==='ok'&&data.result.length===clArr.length){
								data.result.map(function(value,index){
									clArr[index].busyness = value.busyness;
								})
							}else{
								console.log("常乘坐站点，地铁繁忙程度获取失败："+data);
							}
							console.log(clArr)
							_this.commonLineDt = clArr;
						})
					}else{
						console.dir(data);
					}
				});
			},
			getBusyDegDt: function(cmd,stationnos,callback){//查询地铁繁忙程度
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/metrostation.php','post',{'cmd': cmd,'stationnos': stationnos},function(data){
//					_this.busyDegGj = data.result;
//					console.log(data)
					callback(data);
				});
			},
			storeHistory: function(name,code,param){
				var local = JSON.parse(localStorage.getItem(param))||[];
				var obj = {};
				obj.name = name;
				obj[param] = code;
				for(var i=0;i<local.length;i++){
					if(local[i][param]*1===code*1)return;
				}
				if(local.length>=3){//删除最后一个记录
					local.splice(local.length-1,1);
				}
				local.unshift(obj);//添加一条新纪录
				localStorage.setItem(param,JSON.stringify(local));
				this.updateHis();
//				this.$emit("storeHis")
			},
			updateHis: function(){
				this.getHistoryDt();
				this.getHistoryGj();
			},
			updateTag: function(val){
				this.tabActive = val;
			},
			mySwiper: function(){
				var _this = this;
				var swiper = new Framework7().swiper('.swiper-container', {
					autoplay : 4000,
					//loop : true,
					observer: true,//修改swiper自己或子元素时，自动初始化swiper 
					observeParents:false,//修改swiper的父元素时，自动初始化swiper
					effect : 'slide',
					//slidesOffsetBefore : 15,
					spaceBetween : 10,
					width : 270,
					pagination : '.swiper-pagination',
					//bulletClass: 'chanpin-bullet',
       				//bulletActiveClass: '.defineDot',
					paginationBulletRender: function (swiper, index, className) {
				    	return '<span class="'+className+'"><div style="width=100%;height:100%;background:#ccc;border-radius:100%;"></div></span>';
				   },
				  	onSlideChangeEnd: function(swiper){
				  		
				  	}
				});
				return swiper;
			},
			tab: function(which){
				switch (which){
					case 'gj':
						this.tabActive = true;
						break;
					case 'dt':
						this.tabActive = false;
						break;
				}
			}
		},
		watch: {
			historyGj: function(arr){
				try{
					if(arr.length===0){
						this.$refs.historyGj_slide.setAttribute('class','');
						this.$refs.historyGj_slide.style.display = "none";
						this.mySwiper();
					}else{
						this.$refs.historyGj_slide.setAttribute('class','swiper-slide');
						this.$refs.historyGj_slide.style.display = "block";
						this.mySwiper();
					}
				}catch(e){
					console.log(e)
				}
			},
			historyDt: function(arr){
				try{
					if(arr.length===0){
						this.$refs.historyDt_slide.setAttribute('class','');
						this.$refs.historyDt_slide.style.display = "none";
						this.mySwiper();
					}else{
						this.$refs.historyDt_slide.setAttribute('class','swiper-slide');
						this.$refs.historyDt_slide.style.display = "block";
						this.mySwiper();
					}
				}catch(e){
					console.log(e)
				}
			}
//			commonLineGj: function(){//常乘坐数据出来就去依此获取相应繁忙程度
//				var _this = this;
//				this.getBusyDegGj('busy',(function(){
//					var arr=[];
//					_this.commonLineGj.map(function(value,index){
//						arr.push(value.lineno);
//					})
//					return arr;
//				})(),function(data){
//					console.log(data)
//					_this.commonLineBusyDegGj = (function(){
//						var arr=[];
//						data.result.map(function(value,index){
//							arr.push(value.busyness);
//						})
//						return arr;
//					})();
//				})
//			}
		}
	}
	
</script>

<style scoped>
	.pages{
		/*height: 50vh;*/
	}
	.trafficBox {
		height: 100vh;
	}
	.tabs-animated-wrap > .tabs > .tab{
		overflow: hidden;
	}
	.buttons-row .button:first-child{
		border-left-style: none;
	}
	.button{
		border: none;
		color: #FFFFFF;
		line-height: 2.5rem;
		font-size: 1.6rem;
		
	}
	.button:not(.active).active-state {
		background: transparent;
	}
	.tabBox{
		overflow: hidden;
		position: relative;
		height: 34.2vw;
		background:url(../assets/Group_7@2x.png) left bottom no-repeat,linear-gradient(180deg,#30ca81, #68df9d);
		background-size: 100% auto;
	}
	.btnBox{
		margin-top: 2rem;
	}
	.button.active {
		background: none;
	    color: #fff;
	}
	.button.active span{
		/*padding: 0.5rem 0;*/
		border-bottom: 0.2rem solid #fff;
	}
	.searchIn{
		background: #FFFFFF;
		border-radius: 0.2rem;
		height: 3rem;
	}
	.searchIn i,.navSearch_in{
		vertical-align: middle;
	}
	.searchIn i{
		display: inline-block;
		font-size: 2rem;
		line-height: 3rem;
		margin: 0 1rem;
		color: #4b4b4b;
	}
	.navSearch_in{
		display: inline-block;
		width: 80%;
		height: 3rem;
		line-height: 3rem;
		border: none;
		font-size: 1.4rem;
	}
	.btn_navSearch{
		width: 100%;
		border: none;
		background: #FFFFFF;
		line-height: 3rem;
		border-radius: 0.2rem;
		color: #2BA728;
		font-size: 1.4rem;
		text-align: center;
	}
	.searchTs{
		background: #FFFFFF;
		border-radius: 0.8rem;
		box-shadow: 0 2px 6px #dedede;
		/*min-height: 15rem;*/
	}
	.searchTs_t{
		line-height: 3rem;
		color: #666666;
		font-size: 1.2rem;
		padding: 0 1rem;
	}
	.searchTs_l{
		line-height: 4rem;
		color: #333;
		font-size: 1.6rem;
		padding: 0 1rem;
	}
	.searchTs_tag{
		line-height: 2rem;
		width: 6rem;
		font-size: 1.2rem;
		color: #FFFFFF;
		text-align: center;
		float: right;
		border-radius: 0.2rem;
		margin-top: 1rem;
	}
	.st_c_yj{
		background: #f75c5d;
	}
	.st_c_zdyj{
		background: #d0021b;
	}
	.st_c_kx{
		background: #31b716;
	}
	.st_c_top1{
		background: #3480c3;
	}
	.st_c_top2{
		background: #4a90e2;
	}
	.st_c_top3{
		background: #3f98e6;
	}
	.swiper-container{
		overflow: initial;
	}
	.swiper-slide{
		padding-left: 1.5rem;
	}
	/*.swiper-slide:first-child{
		padding-left: 1.5rem !important;
	}*/
	.swiper-container-horizontal > .swiper-pagination-bullets, .swiper-pagination-custom, .swiper-pagination-fraction{
		bottom: -4rem;
	}
	.defineDot{
		background: red !important;
	}
</style>