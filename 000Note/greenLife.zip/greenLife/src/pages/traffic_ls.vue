<template>
	<div class="trafficBox">
		<router-view></router-view>
		<div class="tabBox">
			<div class="buttons-row btnBox">
				<!-- 关联到第一个tab的链接，默认激活 -->
				<a href="#tab1" class="tab-link button" :class="{active: tabActive2}" @click="tabActive2=true;$emit('updateTag',true)"><span>公交</span></a>
				<!-- 关联到第二个tab的链接 -->
				<a href="#tab2" class="tab-link button" :class="{active: !tabActive2}" @click="tabActive2=false;$emit('updateTag',false)"><span>地铁</span></a>
			</div>
			<div class="row" style="padding: 0 1.5rem; margin-top: 2.5rem;" v-show="tabActive2">
			    <div class="col-85" style="width: 86.7%;">
			    	<div class="searchIn">
			    		<i class="iconfont icon-sousuo"></i>
			    		<input type="text" ref="gj_in" class="navSearch_in" placeholder="请输入公交线路名称" v-model="val_gj">
			    	</div>
			    </div>
			    <div class="" style="width: 12%;">
			    	<div class="btn_navSearch">搜索</div>
			    </div>
			</div>
			<div class="row" style="padding: 0 1.5rem; margin-top: 2.5rem;" v-show="!tabActive2">
			    <div class="col-85" style="width: 86.7%;">
			    	<div class="searchIn">
			    		<i class="iconfont icon-sousuo"></i>
			    		<input type="text" ref="dt_in" class="navSearch_in" placeholder="请输入地铁站点名称" v-model="val_dt">
			    	</div>
			    </div>
			    <div class="" style="width: 12%;">
			    	<div class="btn_navSearch">搜索</div>
			    </div>
			</div>
		</div>
		<div class="tabs-animated-wrap" style="overflow-y: auto;">
			<div class="tabs" :style="{transform: transformSty}">
				<!-- Tab 1，默认激活 -->
				<div id="tab1" style="overflow: auto;padding: 34.2vw 0 10vw 0;" class="tab" :class="{active: tabActive2}">
					<div>
						<search-result @storeHis="updateH" v-show="sr_show" :items="gj_historyData" param="lineno" searchUrl="/traffic/traffic_ls/comfort"></search-result>
						<search-result2 @storeHis="updateH"  v-show="!sr_show" :items="gj_searchData" param="lineno" searchUrl="/traffic/traffic_ls/comfort" title="公交线路"></search-result2>
					</div>
				</div>
				<!-- Tab 2 -->
				<div id="tab2" style="overflow: auto;padding: 34.2vw 0 10vw 0;" class="tab" :class="{active: !tabActive2}">
					<search-result @storeHis="updateH" v-show="srDt_show" :items="dt_historyData" param="stationno"  searchUrl="/traffic/traffic_ls/comfort_dt"></search-result>
					<search-result2 @storeHis="updateH" v-show="!srDt_show" :items="dt_searchData" param="stationno"  searchUrl="/traffic/traffic_ls/comfort_dt" title="地铁站点"></search-result2>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import searchResult from '../components/searchResult.vue'
	import searchResult2 from '../components/searchResult2.vue'
	export default {
		props: ['tabActive'],
		data () {
			return {
				tabActive2: this.tabActive,
				gj_historyData: [],
				dt_historyData: [],
				val_gj: '',
				val_dt: '',
				//gj_historyData: [{code:'dt01',name:'近江站'},{code:'dt02',name:'江景路站'},{code:'dt03',name:'钱江路站'}],//地铁历史记录
				gj_searchData: [],//公交查询
				dt_searchData: [],//地铁查询
			}
		},
		computed: {
			transformSty: function(){
				var arr = ['translate3d(-100%, 0px, 0px)','translate3d(0%, 0px, 0px)'];
				if(this.tabActive2){
					return arr[1];
				}else{
					return arr[0];
				}
			},
			sr_show: function(){
				if(this.val_gj.length>0){
					return false;
				}else{
					return true;
				}
			},
			srDt_show: function(){
				if(this.val_dt.length>0){
					return false;
				}else{
					return true;
				}
			},
		},
		created: function(){
			this.getHistoryGj();
			this.getHistoryDt();
		},
		mounted: function(){
			this.updateH();
			if(this.tabActive2){
				$(this.$refs.gj_in).focus()
				//this.$refs.gj_in.autofocus = true;
			}else{
				$(this.$refs.dt_in).focus()
				//this.$refs.dt_in.autofocus = true;
			}
		},
		components: {searchResult,searchResult2},
		methods: {
			updateH: function(){
				this.getHistoryGj();
				this.getHistoryDt();
				//console.log(this.gj_historyData);
				this.$emit("updateHis");
			},
			getHistoryGj: function(){//公交历史纪录
				var historyGj = JSON.parse(localStorage.getItem('lineno'));
				//console.log(historyGj.name)
				this.gj_historyData = historyGj;
			},
			getHistoryDt: function(){//地铁历史纪录
				var historyDt = JSON.parse(localStorage.getItem('stationno'));
				this.dt_historyData = historyDt;
			},
			getSearchData: function(cmd,name,forWhich,_interface){//公交线路查询
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/'+_interface,'post',{'cmd': cmd,'name': name},function(data){
					if(data.status==='ok'){
						//console.log(data);
						_this[forWhich] = data.result.line;
					}else{
						console.log(data);
					}
				});
			},
		},
		watch: {
			val_gj: function(val){
				this.getSearchData('bus',val,'gj_searchData','busline.php');
			},
			val_dt: function(val){
				this.getSearchData('metro',val,'dt_searchData','metrostation.php');
			},
//			gj_searchData: function(data){
//				if(data.length>5){
//					
//				}
//			}
		}
	}
	
</script>

<style scoped>
	.trafficBox {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 100;
		background: #f5f4f9;
	}
	.tabs-animated-wrap > .tabs > .tab{
		overflow: hidden;
	}
	.buttons-row .button:first-child{
		border-left-style: none;
	}
	.button{
		border: none;
		color: #FFFFFF;
		line-height: 2.5rem;
		font-size: 1.6rem;
		
	}
	.button:not(.active).active-state {
		background: transparent;
	}
	.tabBox{
		overflow: hidden;
		position: fixed;
		left: 0;
		top: 0;
		z-index: 2;
		width: 100%;
		height: 34.2vw;
		background:url(../assets/Group_7@2x.png) left bottom no-repeat,linear-gradient(180deg,#30ca81, #68df9d);
		background-size: 100% auto;
	}
	.btnBox{
		margin-top: 2rem;
	}
	.button.active {
		background: none;
	    color: #fff;
	}
	.button.active span{
		/*padding: 0.5rem 0;*/
		border-bottom: 0.2rem solid #fff;
	}
	.searchIn{
		background: #FFFFFF;
		border-radius: 0.2rem;
		height: 3rem;
	}
	.searchIn i,.navSearch_in{
		vertical-align: middle;
	}
	.searchIn i{
		display: inline-block;
		font-size: 2rem;
		line-height: 3rem;
		margin: 0 1rem;
		color: #4b4b4b;
	}
	.navSearch_in{
		display: inline-block;
		width: 80%;
		height: 3rem;
		line-height: 3rem;
		border: none;
		font-size: 1.4rem;
	}
	.btn_navSearch{
		width: 100%;
		border: none;
		background: #FFFFFF;
		line-height: 3rem;
		border-radius: 0.2rem;
		color: #2BA728;
		font-size: 1.4rem;
		text-align: center;
	}
	.searchTs{
		background: #FFFFFF;
		border-radius: 0.8rem;
		box-shadow: 0 2px 6px #dedede;
	}
	.searchTs_t{
		line-height: 3rem;
		color: #666666;
		font-size: 1.2rem;
		padding: 0 1rem;
	}
	.searchTs_l{
		line-height: 4rem;
		color: #333;
		font-size: 1.6rem;
		padding: 0 1rem;
	}
	.searchTs_tag{
		line-height: 2rem;
		width: 6rem;
		font-size: 1.2rem;
		color: #FFFFFF;
		text-align: center;
		float: right;
		border-radius: 0.2rem;
		margin-top: 1rem;
	}
	.st_c_yj{
		background: #f75c5d;
	}
	.st_c_zdyj{
		background: #d0021b;
	}
	.st_c_kx{
		background: #31b716;
	}
	.st_c_top1{
		background: #3480c3;
	}
	.st_c_top2{
		background: #4a90e2;
	}
	.st_c_top3{
		background: #3f98e6;
	}
	.swiper-container{
		overflow: initial;
	}
	.swiper-slide{
		
	}
</style>