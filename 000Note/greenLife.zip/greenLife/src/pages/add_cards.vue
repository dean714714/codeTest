<template>
	<div class="page-content">
		<router-view @getCardNum="addCard" :fontCards="data_fjmk"></router-view>
		<div class="content-block-title addCardTile borderT borderB">
			<!--<i class="iconfont icon-tianjia icon_add" @click="actionInfo('添加市民卡请前往[杭州市民卡APP]！')"></i> -->
			<div>市民卡</div>
		</div>
	    <div class="content-block addCardCon">
	      <div class="content-block-inner addedCardB">
	      	<div class="addedCard" v-show="data_jmk.length>0?true:false" v-for="data in data_jmk"  :class="[data.class]" >
	      		<div class="cardInfo">
	      			{{data.name}}<div class="cardNum">{{data.cardno}}</div>
	      		</div>
	      	</div>
	      	<div class="action" v-show="data_jmk.length>0?false:true" style="padding:1rem 1.5rem 2rem 1.5rem;text-align: center">
	      		<img src="../assets/img_search_defaul@2x.png" style="width: 30vw;margin: 0rem auto;"/>
	      		<div style="margin-top: 1.5rem;">请前往【我的】页面进行实名认证~</div>
	      	</div>
	      </div>
	    </div>
	    <div class="content-block-title addCardTile borderT borderB">
			<i class="iconfont icon-tianjia icon_add" @click="$router.push({ path: '/add_cards/add_fjmk' })"></i> 
			<div>杭州通卡/公交卡</div>
		</div>
	    <div class="content-block addCardCon">
	      <div class="content-block-inner addedCardB">
	      	<div class="addedCard card_hzt" v-show="data_fjmk.length>0?true:false" v-for="data in data_fjmk">
	      		<div class="cardInfo">
	      			{{data.name}}<div class="cardNum">{{data.cardno}}</div>
	      		</div>
	      		<div class="delCard" @click="delCardFace(data_fjmk,data.cardno)"><i class="iconfont icon-qingchu"></i></div>
	      	</div>
	      	<div class="action" v-show="data_fjmk.length>0?false:true" style="padding:1rem 1.5rem 2rem 1.5rem;text-align: center">
	      		<img src="../assets/img_search_defaul@2x.png" style="width: 30vw;margin: 0rem auto;"/>
	      		<div style="margin-top: 1.5rem;">请点击右上角进行添加~</div>
	      	</div>
	      </div>
	    </div>
	    <div class="action" style="margin-top: 2rem;">非记名卡的添加仅用于本模块碳减排量的记录</div>
	</div>
</template>

<script>
	
//	var myApp = new Framework7();
//	var $$ = Dom7;
	
	export default {
		data() {
			return {
				data_jmk: [],
				data_fjmk: [],
				f7: {},
			}
		},
		computed: {
			
		},
		mounted: function(){
			this.getCards();
			this.f7 = new Framework7();
			
		},
		methods: {
			addCard: function(data){
				var data_jmk_arr = [],data_fjmk_arr = [];
				for(var i=0;i<data.length;i++){
					var obj = {};
					if(data[i].cardtype==='smk'){
						obj.name = "市民卡";
						obj.class = 'card_smk';
						obj.cardno = data[i].cardno;
						obj.cardtype = data[i].cardtype;
						data_jmk_arr.push(obj);
					}else if(data[i].cardtype==='xfk'){
						obj.name = "记名消费卡";
						obj.class = 'card_xfk';
						obj.cardno = data[i].cardno;
						obj.cardtype = data[i].cardtype;
						data_jmk_arr.push(obj);
					}else if(data[i].cardtype==='hzt'){
						obj.name = "杭州通卡";
						obj.class = 'card_hzt';
						obj.cardno = data[i].cardno;
						obj.cardtype = data[i].cardtype;
						data_fjmk_arr.push(obj);
					}else{
						console.log("未知卡型")
					}
				}
				this.data_fjmk = data_fjmk_arr||[];
				this.data_jmk = data_jmk_arr||[];
			},
			getCards: function(){
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/relation.php','post',{"cmd": "query"},function(data){
					var data = data.cards||[];
					_this.addCard(data);
				});
			},
			delCardFace: function(base,val){
				var _this = this;
				for(var i=0;i<base.length;i++){
					if(base[i].cardno === val){
						//continue;
						new Promise(function(resolve){
							var j=i;
							_this.f7.confirm("确认删除吗？", '',function(){
								//base.splice(i,1);//因为是异步事件，点击的时候i其实是循环结束最后的值
								console.log(j);
								_this.delCardDB(val);
								_this.delStatus = "hello";
								console.log("点击了ok")
								resolve(j);
							},function(){
								console.log("点击了cancel")
							})
						}).then(function(value){
							base.splice(value,1);
						})
					}
				}
			},
			delCardDB: function(value){//删除数据库中的卡
				var _this = this;
				new Promise(function(resolve){
					_this.$ajax.getData("http://192.168.23.95/ajax/relation.php",'post',{"cmd": "remove","cardno":value},resolve);
					//resolve({status:'ok'});////离线测试
				}).then(function(value){
					var status = value.status;
					if(status==='ok'){
						console.log("删除数据库中该卡号成功")
					}else{
						console.log("删除数据库中该卡号失败")
					}
				})
			},
			actionInfo: function(info){
				this.f7.alert(info, '', function () {
			       
			    })
			}
			
		},
//		beforeRouteUpdate (to, from, next) {
//			console.log("hello")
//			//this.$router.push({ path: '/' })
//		}
	}
</script>

<style scoped>
	.content-block-inner::after,.content-block-inner::before{
		display: none;
	}
	.addCardTile{
		position: relative;
		margin: 0;
		padding: 1.5rem;
		background: #f8f8f8;
	}
	.addCardTile div{
		font-size: 1.6rem;
		color: #333333;
		padding-left: 0.5rem;
		border-left: 0.3rem solid #2ba728; 
	}
	.icon_add{
		position: absolute;
		font-size: 3rem;
		right: 0.75rem;
		top: 0.85rem;
	}
	.addCardCon{
		padding: 0;
		margin: 0;
	}
	.addedCardB{
		padding: 2rem 0 0 0;
		margin: 0;
	}
	.addedCard{
		position: relative;
		width: 100vw;
		height: 26.7vw;
	}
	.delCard{
		background: #FFFFFF;
		position: absolute;
		right: 0.6rem;
		top: -0.6rem;
		/*width: 2rem !important;
		height: 2rem !important;*/
		border-radius: 100%;
		text-align: center;
		font-size: 0;
		opacity: 0.6;
	}
	.delCard i{
		display: inline-block;
		font-size: 2rem;
		line-height: 1.6rem;
		margin-left: -1px;
	}
	.card_smk{
		background: url(../assets/bg_smcard_tjk@2x.png) no-repeat left top;
		background-size: 100% 100%;
	}
	.card_xfk{
		background: url(../assets/bg_xfcard_tjk@2x.png) no-repeat left top;
		background-size: 100% 100%;
	}
	.card_hzt{
		background: url(../assets/bg_hztcard_tjk@2x.png) no-repeat left top;
		background-size: 100% 100%;
	}
	.cardInfo{
		position: absolute;
		color: #FFFFFF;
		font-size: 4.6vw;
		line-height: 4.6vw;
		top: 5.3vw ;
		left: 20.3vw;
	}
	.cardInfo .cardNum{
		font-size: 4.2vw;
		line-height: 4.2vw;
		margin-top: 2.5vw;
	}
</style>