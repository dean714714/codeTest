<template>
	<div class="comfort">
		<div class="cf_top">
			<div class="cf_top_info">
				<span class="cf_top_info_b">
					<span ref="lineNamebox">{{lineName}}</span>
					<div class="com_tag" v-show="com_tag1_show">{{comfort}}</div>
					<div class="com_tag" v-show="com_tag2_show">{{comfort2}}</div>
					<div class="com_tag" v-show="com_tag3_show">{{comfort3}}</div>
				</span>路
			</div>
		</div>
		<div class="cf_chart">
			<div class="content-block">
				<!-- tabs控制面板 -->
				<div class="buttons-row">
					<!-- 关联到第一个tab, 默认激活 -->
					<a href="#tab1" class="tab-link active button" @click="tabChart(1)">今天</a>
					<!-- 关联到第二个tab -->
					<a href="#tab2" class="tab-link button" @click="tabChart(2)">明天</a>
					<!-- 关联到第三个tab -->
					<a href="#tab3" class="tab-link button" @click="tabChart(3)">后天</a>
				</div>
			</div>
			<!-- Tabs, 标签内容区容器 -->
			<div class="tabs">
				<div id="tab1" class="tab active">
					<div class="content-block">
						<chart-comfort :chartData='todayData' chartClass="chart1" :chartHeight="chartHeight" @getComfortDeg="setComfortDeg($event,1)" style="width: 92vw;"></chart-comfort>
					</div>
				</div>
				<div id="tab2" class="tab">
					<div class="content-block"><!--:style="{height:chartHeight}"-->
						<chart-comfort :chartData='todayData2' chartClass="chart2" :chartHeight="chartHeight" @getComfortDeg="setComfortDeg($event,2)" style="width: 92vw;"></chart-comfort>
					</div>
				</div>
				<div id="tab3" class="tab">
					<div class="content-block">
						<chart-comfort :chartData='todayData3' chartClass="chart3" :chartHeight="chartHeight" @getComfortDeg="setComfortDeg($event,3)" style="width: 92vw;"></chart-comfort>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	
	import chartComfort from '../components/chartComfort.vue';
	export default {
		data() {
			return {
				chartHeight: '20rem',
				todayData: [],
				comfort: '',
				comfort2: '',
				comfort3: '',
				//[120, 125, 101, 122, 90, 30, 110, 110, 101, 114, 10, 20, 24, 32, 101, 125, 90, 104, 110, 120, 44, 104, 90, 14,4],
				todayData2: [],
				todayData3: [],
				comfortDegMap: [
					{busyness:0,des:'非常舒适'},
					{busyness:1,des:'舒适'},
					{busyness:2,des:'轻度拥挤'},
					{busyness:3,des:'拥挤'},
					{busyness:4,des:'重度拥挤'}
				],
				com_tag1_show: true,
				com_tag2_show:false,
				com_tag3_show:false,
			}
		},
		computed: {
			todayD: function(){
				return (function(){
					var year = new Date().getFullYear()+'';
					var month = (function(){
						if(new Date().getMonth()*1+1<10){
							return '0'+(new Date().getMonth()*1+1);
						}else{
							return ''+(new Date().getMonth()*1+1);
						}
					})();
					var day = (function(){
						if(new Date().getDate()*1<10){
							return '0'+new Date().getDate()*1;
						}else{
							return ''+new Date().getDate()*1;
						}
					})();
					return year+month+day;
				})()
			},
			tomorrowD: function(){
				return (function(){
					var _date = new Date();
					_date.setDate(_date.getDate()+1);
					var year = _date.getFullYear()+'';
					var month = (function(){
						if(_date.getMonth()*1+1<10){
							return '0'+(_date.getMonth()*1+1);
						}else{
							return ''+(_date.getMonth()*1+1);
						}
					})();
					var day = (function(){
						if(_date.getDate()*1<10){
							return '0'+_date.getDate()*1;
						}else{
							return ''+_date.getDate()*1;
						}
					})();
					return year+month+day;
				})()
			},
			thirdD: function(){
				return (function(){
					var _date = new Date();
					_date.setDate(_date.getDate()+2);
					var year = _date.getFullYear()+'';
					var month = (function(){
						if(_date.getMonth()*1+1<10){
							return '0'+(_date.getMonth()*1+1);
						}else{
							return ''+(_date.getMonth()*1+1);
						}
					})();
					var day = (function(){
						if(_date.getDate()*1<10){
							return '0'+_date.getDate()*1;
						}else{
							return ''+_date.getDate()*1;
						}
					})();
					return year+month+day;
				})()
			},
			lineName: function(){
				var urlHash = location.hash;
				var name = (function(){
					return urlHash.split('?')[1].split("&")[1].split('=')[1]
				})()
				return decodeURI(name).replace(/\s+/g, "");//去空格
			},
			lineCode: function(){
				var urlHash = location.hash;
				var code = (function(){
					return urlHash.split('?')[1].split("&")[0].split('=')[1]
				})()
				return code;
			}
		},
		created: function(){

		},
		mounted: function(){
			this.$emit('updateTag',true);//为了返回时tab标签傻逼一样的激活状态会丢失
			
			this.getChartData('flow',this.lineCode,this.todayD,'todayData')
			var winH = document.documentElement.clientHeight;
			var cf_topH = document.querySelector('.cf_top').clientHeight;
			var content_blockH = document.querySelector('.content-block').clientHeight+50;
			this.chartHeight = winH-cf_topH-content_blockH+'px';
			
			var lineNamelength = this.getLength(this.lineName);
			if(lineNamelength>7){
				this.$refs.lineNamebox.style.fontSize = 100/lineNamelength+'vw';
			}
		},
		components: {chartComfort},
		methods: {
			getChartData: function(cmd,code,date,forWhichDay){//公交繁忙&舒适度查询
				var _this = this;
				this.$ajax.getData('http://192.168.23.95/ajax/busline.php','post',{'cmd': cmd,'lineno':code,'date':date},function(data){
					if(data.status==='ok'){
						//console.log(data);
						_this[forWhichDay] = data.result;
					}else{
						console.log(data);
					}
				});
			},
			tabChart: function(index){
				if(index===1){
					this.getChartData('flow',this.lineCode,this.todayD,'todayData');
					this.com_tag1_show = true;
					this.com_tag2_show = false;
					this.com_tag3_show = false;
				}
				if(index===2){
					this.getChartData('flow',this.lineCode,this.tomorrowD,'todayData2');
					this.com_tag1_show = false;
					this.com_tag2_show = true;
					this.com_tag3_show = false;
				}
				if(index===3){
					this.getChartData('flow',this.lineCode,this.thirdD,'todayData3');
					this.com_tag1_show = false;
					this.com_tag2_show = false;
					this.com_tag3_show = true;
				}
			},
			setComfortDeg: function(data,index){
				if(index===1){
					this.comfort = data;
				}
				if(index===2){
					this.comfort2 = data;
				}
				if(index===3){
					this.comfort3 = data;
				}
			},
			getLength: function(str){  
			    var realLength = 0;  
			    for (var i = 0; i < str.length; i++)   
			    {  
			        var charCode = str.charCodeAt(i);  
			        if (charCode >= 0 && charCode <= 128)   
			        realLength += 1;  
			        else   
			        realLength += 2;  
			    } 
			    return realLength;
			},
		},
		watch: {
			todayData: function(data){
				var deg = data.comfort;
				this.comfort = this.comfortDegMap[deg].des;
			},
			todayData2: function(data){
				var deg = data.comfort;
				this.comfort2 = this.comfortDegMap[deg].des;
			},
			todayData3: function(data){
				var deg = data.comfort;
				this.comfort3 = this.comfortDegMap[deg].des;
			},
		}
	}
	
</script>

<style scoped>
	.comfort{
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 100;
		background: #fff;
	}
	.cf_top{
		position: relative;
		height: 79vw;
		background:url(../assets/img_gj@2x.png) left bottom no-repeat,linear-gradient(180deg,#30ca81, #68e19d);
		background-size: 100% auto;
		overflow: hidden;
	}
	.cf_top_info{
		text-align: center;
		font-size: 5.86vw;
		color: #FFFFFF;
		margin-top: 20vw;
	}
	.cf_top_info .cf_top_info_b{
		position: relative;
		font-size: 19.2vw;
		margin-right: -3vw;
	}
	.com_tag{
		position: absolute;
		font-size: 3.74vw;
		color: #31B716;
		line-height: 5.87vw;
		white-space: nowrap;
		background: #FFFFFF;
		border-radius: 0.2rem;
		padding: 0 0.6rem;
		left: 100%;
		top: 2vw;
	}
	.com_tag::before{
		content: '';
		position: absolute;
		display: block;
		width: 0.7rem;
		height: 0.5rem;
		background:transparent url(../assets/triangle@2x.png)  center center no-repeat;
		background-size: 100% 100%;
		left: 0.2rem;
		bottom: -0.5rem;
	}
	
	.content-block{
		padding: 0 1.5rem;
		margin: 2rem 0;
	}
	.button{
		border:1px solid #2ba728;
		color: #2ba728;
	}
	.buttons-row .button{
		border-left-width: 0;
	}
	.button.active{
		background: #2ba728;
		color: #fff;
	}
	.buttons-row .button:first-child{
		border-left-width: 1px;
		border-left-style: solid;
	}
	.button:not(.active).active-state {
		background: rgba(43,167,40,0.1);
	}
</style>