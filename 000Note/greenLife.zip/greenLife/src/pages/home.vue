<template>
	<span>
		<div class="login-screen">
			<img src="../assets/logo.png" style="width: 80%;margin: 0 auto;margin-top: 25vh;"/>
			<div class="loginCon">
				<div style="margin-top: 5rem;" class="ani" id="loginCon1">
					<div class="formList borderB">
						<div id="getYzm" class="yzmBtn borderL" style="width: 12rem;" @click="getYzm($event,60)">获取验证码</div>
						<input type="tel" class="formIn" name="" ref="phoneNum" value="" placeholder="请输入手机号" v-model="phoneNum"/>
					</div>
					<div class="formList borderB">
						<input type="number" class="formIn" name="" ref="codeNum" value="" placeholder="请输入验证码" v-model="codeNum"/>
					</div>
					<div class="form_btn" style="width: 100%;margin-top: 2.1rem;" @click="loginIn">登录</div>
				</div>
			</div>
		</div>
		<div class="homeTop">
	  		<div class="weather" v-show="weatherIcon">
	  			<!--<i class="iconfont icon-qingchu iconWeather"></i> -->
	  			<img :src="weatherIcon" class="iconWeather"/>
	  			<span class="weatherInfo">{{weather.weather}}</span>
	  			<span class="temperature ">{{weather.temp}}<span class="du">°</span></span>
	  		</div>
	  		<span v-show="ifHasCards">
	  			<div class="btn_addcard"  @click="$router.push({ path: 'add_cards' })" >
	  				<i class="iconfont icon-tianjiayinhangqia iconAddcard"></i> 
	  			</div>
	      		<div class="htChart">
	      			<router-link to="/carbon_detail">
	      				<!--<canvas id="homeCanvas"></canvas>-->
	      				<div id="wave" class="wave"><span><!--60%--></span></div>
	          			<div class="htChartTitle">我的绿色积分</div>
	          			<div class="htChartNum"><span class="counter">{{cTotalNum}}</span></div>
	          			<div class="htChartDate">统计至<span>{{cTotalDate}}</span></div>
	      			</router-link>
	      		</div>
	  		</span>
	  		<span v-show="!ifHasCards" class="noCard">
	  			<div class="noCardInfo">您还没有卡<br/>小编无法为您计算碳减排</div>
	  			<a href="#" class="button color-white noCardBtn" @click="$router.push({ path: 'add_cards_ls' })">
	  				添加卡
	  			</a>
	  		</span>
	  	</div>
	  	<div class="homeNav">
	  		<div class="row subNavGrid">
			    <div class="col-50 subNavCol" style="text-align: center;">
					<div class="subNav" onclick="location.href='https://activity.96225.com/big_data/?ADTAG=yy.smk'"><!--onclick="location.href='http://activity.96225.com/big_data/?ADTAG=yy.smk'" -->
						<span class="icon"><img src="../assets/ic_shyk@2x.png" class="lazy lazy-fadein"/></span>
						<span class="info">生活月刊</span>
					</div>
				</div>
				<div class="col-50 subNavCol" style="text-align: center;">
					<div @click="$router.push({ path: '/traffic'})" class="subNav">
						<span class="icon"><img src="../assets/ic_jtzzd@2x.png" class="lazy lazy-fadein"/></span>
						<span class="info">交通早知道</span>
					</div>
				</div>
			</div> 
	  	</div>
	  	<!--<div @click="access" style="text-align: center;line-height: 8rem;background: #77aaff;color: #fff;margin: 2rem 0;">临时验证</div>-->
	  	<div class="homeBanner">
	  		<div class="swiper-container">
			    <div class="swiper-wrapper">
			        <div class="swiper-slide"  v-for="banner in bannerData">
			        	<div class="banner" onclick="location.href='https://activity.96225.com/big_data/?ADTAG=yy.smk'"><!--onclick="location.href='http://activity.96225.com/big_data/?ADTAG=yy.smk'"-->
							<img :src="banner.imgSrc" class="lazy lazy-fadein"/>
						</div>
			        </div>
			    </div>
			    <div class="swiper-pagination defineSp"></div>
			</div>
	  	</div>
	</span>
</template>

<script>

export default {
	name: 'Home',
	data () {
		return {
			token: '',
			f7: {},
			userId: '',
			phoneNum: '',
			codeNum: '',
			clickOnce: false,
			navData: [
				{imgSrc:require("../assets/ic_shyk@2x.png"),info: "生活月刊",href:"/traffic"},
				{imgSrc:require("../assets/ic_jtzzd@2x.png"),info: "交通早知道",href:"/traffic"}
			],
			bannerData: [
				{imgSrc:require("../assets/banner.png"),href: "/about/"},
				{imgSrc:require("../assets/banner.png"),href: "/about/"},
				{imgSrc:require("../assets/banner.png"),href: "/about/"}
			],
			card: [{}],
			ifHasCards: true,
			cTotalNum: '',
			cTotalDate: '',
			weather: {},
			mateW: [
				{w:'晴',img:require('../assets/qing_icon@2x.png')},
				{w:'多云',img:require('../assets/duoyun_icon@2x.png')},
				{w:'阴',img:require('../assets/yin_icon@2x.png')},
				{w:'阵雨',img:require('../assets/zhenyu_icon@2x.png')},
				{w:'雷阵雨',img:require('../assets/leizhenyu_icon@2x.png')},
				{w:'雷阵雨并伴有冰雹',img:require('../assets/leizhenyubingbanyoubingbao_icon@2x.png')},
				{w:'雨夹雪',img:require('../assets/yujiaxue_icon@2x.png')},
				{w:'小雨',img:require('../assets/xiaoyu_icon@2x.png')},
				{w:'中雨',img:require('../assets/zhongyu_icon@2x.png')},
				{w:'大雨',img:require('../assets/dayu_icon@2x.png')},
				{w:'暴雨',img:require('../assets/baoyu_icon@2x.png')},
				{w:'大暴雨',img:require('../assets/dabaoyu_icon@2x.png')},
				{w:'特大暴雨',img:require('../assets/tedabaoyu_icon@2x.png')},
				{w:'阵雪',img:require('../assets/zhenyu_icon@2x.png')},
				{w:'小雪',img:require('../assets/xiaoxue_icon@2x.png')},
				{w:'中雪',img:require('../assets/zhongxue_icon@2x.png')},
				{w:'大雪',img:require('../assets/daxue_icon@2x.png')},
				{w:'暴雪',img:require('../assets/baoxue_icon@2x.png')},
				{w:'雾',img:require('../assets/wu_icon@2x.png')},
				{w:'冻雨',img:require('../assets/zhenyu_icon@2x.png')},
				{w:'沙尘暴',img:require('../assets/shachenbao_icon@2x.png')},
				{w:'小雨-中雨',img:require('../assets/xiaoyu_icon@2x.png')},
				{w:'中雨-大雨',img:require('../assets/zhongyu_icon@2x.png')},
				{w:'大雨-暴雨',img:require('../assets/dayu_icon@2x.png')},
				{w:'暴雨-大暴雨',img:require('../assets/baoyu_icon@2x.png')},
				{w:'大暴雨-特大暴雨',img:require('../assets/dabaoyu_icon@2x.png')},
				{w:'小雪-中雪',img:require('../assets/xiaoyu_icon@2x.png')},
				{w:'中雪-大雪',img:require('../assets/zhongxue_icon@2x.png')},
				{w:'大雪-暴雪',img:require('../assets/daxue_icon@2x.png')},
				{w:'浮尘',img:require('../assets/fuchen_icon@2x.png')},
				{w:'扬沙',img:require('../assets/yangsha_icon@2x.png')},
				{w:'强沙尘暴',img:require('../assets/qiangshachenbao_icon@2x.png')},
				{w:'飑',img:require('../assets/biao_icon@2x.png')},
				{w:'龙卷风',img:require('../assets/longjuanfeng_icon@2x.png')},
				{w:'弱高吹雪',img:require('../assets/ruogaochuixue_icon@2x.png')},
				{w:'轻雾',img:require('../assets/qingwu_icon@2x.png')},
				{w:'霾',img:require('../assets/mai_icon@2x.png')},
			]
		}
	},
	computed: {
		weatherIcon: function(){
			if(!this.weather){
				return false;
			}
			var wea = this.weather.weather,noHas=false,imgSrc='';
			this.mateW.map(function(value,index){
				if(value.w===wea){
					imgSrc = value.img;
				}else{
					//noHas = imgSrc?false:true;
				}
			})
			if(noHas){
				//console.log("没有匹配天气!");
			}
			return imgSrc;
		}
	},
	mounted: function(){
		
		var _this = this;
		//this.getCards();//判断是否有卡
		//this.getWeather();//天气
		//this.getC();//总碳排放
		//初始化swiper
		this.f7 = new Framework7(); 
		var mySwiper = this.f7.swiper('.swiper-container', {
			effect : 'slide',
		    speed: 400,
		    slidesOffsetBefore : 0,
			spaceBetween : 0,
			width: window.innerWidth,
			//pagination : '.swiper-pagination',
		});
		
		var loginStatus = localStorage.getItem("loginStatus")||'false';
		
		if(loginStatus==='false'){
			if(!isApp('smkVersion')){//如果非APP环境
				if(localStorage.getItem('userId')){//如果有本地userId免密登录
					console.log("hello");
					this.userId = localStorage.getItem('userId');
					this.quickIn().then(function(value){
						_this.getCards();//判断是否有卡
						_this.getWeather();//天气
						_this.getC();//总碳排放
					})
				}else{//否则手机验证码快捷登录
					this.f7.loginScreen();
				}
			}else{//app环境
				this.getToken().then(function(value){
					if(_this.token===''){
						_this.actionInfo("用户身份获取失败，请登录！",function(){
							_this.f7.loginScreen();
						})
						return;
					}
					_this.getUserIdByToken().then(function(value){
						_this.quickIn().then(function(value){
							_this.getCards();//判断是否有卡
							_this.getWeather();//天气
							_this.getC();//总碳排放
						})
					})
				})
			}
		}else{
			if(!isApp('smkVersion')){//如果非APP环境
				this.userId = localStorage.getItem('userId');
				this.quickIn().then(function(value){
					_this.getCards();//判断是否有卡
					_this.getWeather();//天气
					_this.getC();//总碳排放
				})
			}else{//app环境
				this.getToken().then(function(value){
					if(_this.token===''){
						_this.actionInfo("用户身份获取失败，请登录！",function(){
							_this.f7.loginScreen();
						})
						return;
					}
					_this.getUserIdByToken().then(function(value){
						_this.quickIn().then(function(value){
							_this.getCards();//判断是否有卡
							_this.getWeather();//天气
							_this.getC();//总碳排放
						})
					})
				})
			}
		}
		
		
	},
	methods: {
		getToken: function(){//获取token
			var _this = this;
//			if(!onloadStatus){//解决onlod有时候不执行的情况
//				var onloadFun = window.onload;
//				onloadFun();
//				onloadStatus = true
//			}
			return new Promise(function(resolve){
				//判断APP版本信息
				var version = _this.getVersion();
				//alert(version)
				if(version>=40100){//版本4.1.0开始使用token的方式获取version>=40100
					var xl = setInterval(function(){//轮询token,因为有可能延时
						if(appGetData){
							clearInterval(xl);
							_this.token = appGetData;
							console.log(_this.token)
							//_this.actionInfo(appGetData)
							resolve();
						}
					},100)
				}else{
					_this.token = location.search.split('token=')[1]||"";//如果url都没有token即版本过低，token为空，下述初始化会显示错误页面
					resolve();
				}
			})
				
		},
		getUserIdByToken: function(){//通过token获取userId
			var _this = this;
			return new Promise(function(resolve){
				_this.$ajax.getData('http://192.168.23.95/ajax/auth.php','post',{"cmd": "siginInByAppAccessToken", "token":_this.token},resolve);
				//_this.$ajax.getData('http://localhost:3000/getUserIdByToken','get',{},resolve);
				//resolve({status:'ok',account:'f9718214514e4f01baf775a96be3d1d7'})
			}).then(function(value){
					var status = value.status;
					if(status==='ok'){
						//localStorage.setItem("userId",value.account);
						//_this.actionInfo("userId:"+value.account)
						_this.userId = value.account;
					}
				})
		},
		quickIn: function(){
			var _this = this;
			return new Promise(function(resolve){
				_this.$ajax.getData('http://192.168.23.95/ajax/auth.php','post',{"cmd": "siginInByAccessCode", "userid":_this.userId,"ac":"biginsight"},resolve);
				//_this.$ajax.getData('http://localhost:3000/quickIn','get',{},resolve);
				//resolve({status:'ok'})
			}).then(function(value){
				var status = value.status;
				if(status==='fail'){
					_this.actionInfo("免登验证失败请重新进入！")
					return;
				}else{
					localStorage.setItem('loginStatus','true')
					//_this.actionInfo("app登入成功！")
				}
			})
		},
		//验证码倒计时
		getYzm: function($event,time){
			var _this = this;
			//倒计时操作
			var obj = $event.target;
			if(this.checkPhone()){
				(!isNaN($(obj).html().split('s')[0]))
				?(function(){
					_this.actionInfo("请倒计时结束再重新获取！");
					return;
				})()
				:(function(){
					new Promise(function(resolve){//获取验证码
						_this.$ajax.getData("http://192.168.23.95/ajax/auth.php",'post',{"cmd": "getValidCode", "mobile":_this.phoneNum},resolve);
						//resolve();//离线测试
					}).then(function(value){
						//console.log("验证码发送状态："+value.status)
						$(obj).html(time+'s');
						var yzmAni = setInterval(function(){
							$(obj).html().split('s')[0]*1>0
							?$(obj).html($(obj).html().split('s')[0]*1-1+'s')
							:(function(){
								clearInterval(yzmAni);
								$(obj).html("获取验证码");
							})();
						},1000)
					})
				})()
			}
		},
		//检查是否手机号是否合规
		checkPhone: function(){
			var value = this.phoneNum;
			var r = /^1[1234567890][0-9]{9}$/;
			if(!value){
				this.actionInfo("手机号不能为空！")
				return false;
			}else{
				if(r.test(value)){
					return true;
				}else{
					this.actionInfo('手机号输入错误,请重新输入'); 
					return false;
				}
			}
			
		},
		//检查验证码是否正确
		checkCode: function(){
			var _this = this;
			return	new Promise(function(resolve){//验证验证码
					_this.$ajax.getData("http://192.168.23.95/ajax/auth.php",'post',{"cmd": "siginInByMobile","mobile":_this.phoneNum ,"vc": _this.codeNum},resolve);
					//resolve({status:'ok'});////离线测试
				}).then(function(value){
					var status = value.status;
					if(status==='ok'){
						console.log("验证码验证成功！")
					}else{
						_this.actionInfo('验证码不正确，请确认输入！')
					}
					return status;
				})
			//}
			
		},
		loginIn: function(){
			var _this = this;
			_this.clickOnce===false?_this.clickOnce=true:(function(){return;})()//此步程序基本走完才能再次点击
			var phoneNum = this.phoneNum;
			var codeNum = this.codeNum;
			if(!phoneNum||!codeNum){
				this.actionInfo("手机号或验证码不能为空，请确认！")
			}else{
				this.checkCode().then(function(value){
					if(value!='fail'){
						$("#getYzm").html()==='获取验证码'
						?(function(){return;})()
						:$("#getYzm").html(0+'s');//关闭倒计时以防退出再看到倒计时
						
						_this.getUserInfo();
						
						
					}else{
						return;
					}
					_this.clickOnce = false;
				});
				
			}
		},
		//通过手机号获取用户id,用户名,等级和卡信息
		getUserInfo: function(){
			var _this = this;
			return	new Promise(function(resolve){//获取用户信息
				_this.$ajax.getData("http://192.168.23.95/ajax/auth.php",'post',{"cmd": "getUserSummary"},resolve);
				//var json = {userlevel:2,userid:'2349skdjfi923jsid'};//离线测试
				//resolve(json);
			}).then(function(value){
				_this.userId = value.userid||'';
				localStorage.setItem("userId",_this.userId);
				localStorage.setItem('loginStatus','true');
				//获取用户卡信息
				_this.getCards();//判断是否有卡
				_this.getWeather();//天气
				_this.getC();//总碳排放
				
				_this.f7.confirm('恭喜您！登录成功！', function () {
			       _this.f7.closeModal(".login-screen")
			    });
			})
				
		},
		getVersion: function(){
			var ua = window.navigator.userAgent.split("smkVersion/")[1]||'';
			var version;
			if(!ua.split(' ')[1]){//如果之后没有别的ua了
				//version = parseInt(ua.split(' ')[0].split('.').join(""));
				version = (function(){
					var arr = ua.split(' ')[0].split('.');
					for(var i=0;i<arr.length;i++){
						if(arr[i]*1<10){arr[i] = ("0"+arr[i])};//为单数加0防止版本号有些是单数有些是双数
					}
					return arr.join("")*1;
				})()
			}else{
				//version = parseInt(ua.substring(0,ua.indexOf(' ')).split('.').join(""));
				version = (function(){
					var arr = ua.substring(0,ua.indexOf(' ')).split('.');
					for(var i=0;i<arr.length;i++){
						if(arr[i]*1<10){arr[i] = ("0"+arr[i])};
					}
					return arr.join("")*1;
				})()
			}
			return version;
		},
		
		actionInfo: function(info,callback){
			this.f7.alert(info, '', callback)
		},
		getCards: function(){
			var _this = this;
			return new Promise(function(resolve){
				_this.$ajax.getData('http://192.168.23.95/ajax/relation.php','post',{"cmd": "query"},resolve);
			}).then(function(data){
				if(data.status==='ok'){
					_this.ifHasCards = true;
				}else{
					_this.ifHasCards = false;
				}
				//_this.ifHasCards = false;
			})
			
		},
		getC: function(){//碳总量接口数据获取
			var _this = this;
			return new Promise(function(resolve){
				_this.$ajax.getData('http://192.168.23.95/ajax/accumulation.php','post',{},resolve);
			}).then(function(data){
				_this.cTotalNum = data.cardInfo.total?(Math.round((data.cardInfo.total*1/100))+''):0;
				_this.cTotalDate = (data.cardInfo.date+'').substring(0,4)+'-'+(data.cardInfo.date+'').substring(4,6)+'-'+(data.cardInfo.date+'').substring(6,8);
				//localStorage.setItem('cTotalNum',_this.cTotalNum);
			})
		},
		getWeather: function(){//天气接口
			if((typeof getWeatherInfo)==="undefined"){
				this.weather = false;
				return;
			}
			var weather = getWeatherInfo(),obj={},nowHour= new Date().getHours(),
			daytemp = weather.forecasts[0].casts[0].daytemp,
			dayweather = weather.forecasts[0].casts[0].dayweather,
			nighttemp = weather.forecasts[0].casts[0].nighttemp,
			nightweather = weather.forecasts[0].casts[0].nightweather;
			if(nowHour>=6&&nowHour<=18){
				obj.temp = daytemp;
				obj.weather = dayweather;
			}else{
				obj.temp = nighttemp;
				obj.weather = nightweather;
			}
			this.weather = obj;
			//this.weather = {temp:'32',weather: 'hello'}
		},
		wave: function(isAddY){//波浪动画
		    var ctx;
		    var waveImage;
		    var canvasWidth;
		    var canvasHeight;
		    var needAnimate = false;
	
		    function init (callback) {
		        var wave = document.getElementById('wave');
		        var canvas = document.createElement('canvas');
		        if (!canvas.getContext) return;
		        ctx = canvas.getContext('2d');
		        canvasWidth = wave.offsetWidth;
		        canvasHeight = wave.offsetHeight;
		        canvas.setAttribute('width', canvasWidth);
		        canvas.setAttribute('height', canvasHeight);
		        wave.appendChild(canvas);
		        waveImage = new Image();
		        waveImage.onload = function () {
		            waveImage.onload = null;
		            callback();
		        }
		        waveImage.src = require('../assets/wave.png');
		    }
	
		    function animate (isAddY) {
		        var waveX = 0;
		        var waveY = 0;
		        var waveX_min = -203;
		        var waveY_max = canvasHeight * 0.7;
		        if(isAddY){
		        	waveY = waveY_max;
		        }else{
		        	waveY = 0;
		        }
		        console.log("waveY:"+waveY)
		        var requestAnimationFrame = 
		            window.requestAnimationFrame || 
		            window.mozRequestAnimationFrame || 
		            window.webkitRequestAnimationFrame || 
		            window.msRequestAnimationFrame ||
		            function (callback) { window.setTimeout(callback, 1000 / 60); };
		        function loop () {
		            ctx.clearRect(0, 0, canvasWidth, canvasHeight);
		            if (!needAnimate) return;
		            if (waveY < waveY_max) waveY += 1.5;
		            if (waveX < waveX_min) waveX = 0; else waveX -= 1.5;
		            
		            ctx.globalCompositeOperation = 'source-over';
		            ctx.beginPath();
		            ctx.arc(canvasWidth/2, canvasHeight/2, canvasHeight/2, 0, Math.PI*2, true);
		            ctx.closePath();
		            ctx.fill();
	
		            ctx.globalCompositeOperation = 'source-in';
		            ctx.drawImage(waveImage, waveX, canvasHeight - waveY);
		            
		            requestAnimationFrame(loop);
		        }
		        loop();
		    }
	
		    function start () {
		    	console.log("isAddY:"+isAddY);
		        if (!ctx) return init(start);
		        needAnimate = true;
		        setTimeout(function () {
		            if (needAnimate) animate(isAddY);
		        }, 500);
		    }
		    function stop () {
		        needAnimate = false;
		    }
		    return {start: start, stop: stop};
		}
	},
	watch: {
		cTotalNum: function(val){
			
			console.log("val:"+val)
			if(localStorage.getItem('cTotalNum')+''===val+''){
				console.log("新旧一致")
				$(".counter").SmkScrollNumber({
	                num: val,
	                speed: 0
	            })
				var wave = this.wave(true)||(function(){return})();
				wave.start();
			}else{
				console.log("新旧不一致")
				$(".counter").SmkScrollNumber({
	                num: val,
	                speed: 2500
	            })
				var wave = this.wave(false)||(function(){return})();
				wave.start();
				localStorage.setItem('cTotalNum',this.cTotalNum);
			}
		}
	}
}
</script>

<style type="text/css" scoped>
	.wave {
		width: 100%;
		height: 100%;
		overflow: hidden;
		border-radius: 100%;
		background: rgba(255, 255, 255, .6);
		position: relative;
		text-align: center;
		vertical-align: middle;
	}
	.wave canvas {
		position: absolute;
		left: 0;
		top: 0;
		z-index: 1;
	}
	
	.homeTop {
		position: relative;
		height: 74.6vw;
		background: url(../assets/img_home@2x.png) left bottom no-repeat, linear-gradient(180deg, #30ca81, #68df9d);
		background-size: 100% auto;
	}
	
	.noCard {
		position: absolute;
		top: 8.5rem;
		width: 100%;
		text-align: center;
		color: #fff;
		font-size: 1.4rem;
		letter-spacing: 0.1rem;
	}
	
	.noCardBtn {
		display: inline-block;
		width: 40vw;
		margin-top: 1.8rem;
	}
	
	.htChart {
		position: absolute;
		width: 41.6vw;
		height: 41.6vw;
		left: 29.2vw;
		top: 6rem;
		letter-spacing: 1px;
	}
	
	.htChartTitle {
		position: absolute;
		width: 100%;
		text-align: center;
		color: #349f94;
		font-size: 1.2rem;
		top: 2.2rem;
	}
	
	.htChartNum {
		position: absolute;
		width: 100%;
		text-align: center;
		color: #00887b;
		font-weight: 600;
		font-size: 2.4rem;
		top: 7rem;
	}
	
	.htChartNum span {
		font-weight: bold;
		font-size: 2.4rem;
	}
	
	.htChartDate {
		position: absolute;
		width: 100%;
		text-align: center;
		color: #999;
		font-size: 1rem;
		letter-spacing: normal;
		top: 12rem;
	}
	
	#homeCanvas {
		width: 150px;
		height: 150px;
		/*width: 41.6vw;
		height: 41.6vw;*/
		/*border-radius: 100%;*/
		background: rgba(255, 255, 255, 0.9);
	}
	
	.btn_addcard {
		position: absolute;
		left: 11vw;
		top: 12rem;
		width: 3.5rem;
		height: 3.5rem;
		background: #fff;
		text-align: center;
		border-radius: 100%;
	}
	
	.iconAddcard {
		color: #2ba728;
		font-size: 2rem;
		line-height: 3.5rem;
	}
	
	.weather {
		position: absolute;
		top: 2.1rem;
		right: 4.26vw;
		line-height: 1.8rem;
		font-size: 1.4rem;
		color: #fff;
		text-align: right;
	}
	
	.weatherInfo,
	.temperature,
	.iconWeather {
		vertical-align: middle;
	}
	
	.iconWeather {
		display: inline-block;
		height: 1.8rem;
	}
	
	.homeNav {
		padding: 2rem 0;
		background: #fff;
	}
	
	.homeBanner {
		position: fixed;
		bottom: 0;
		background: #fff;
		height: 29.3vw;
	}
	
	.subNavGrid {
		/*justify-content: flex-start;
		align-items: flex-start;*/
	}
	
	.subNavCol {
		width: 50vw !important;
		/*flex-grow:0;*/
	}
	
	.subNav {
		display: inline-block;
		width: 100%;
		color: #333;
	}
	
	.subNav:hover {
		/*background: #f5f5f5;*/
	}
	
	.subNav:first-child {
		border-right: 1px solid #f0f0f0;
	}
	
	.subNav .info,
	.subNav .icon {
		display: inline-block;
		vertical-align: middle;
	}
	
	.subNav .info {
		margin-left: 1rem;
	}
	
	.subNav .icon img {
		width: 4rem;
		height: 4rem;
	}
	
	.banner,.banner img {
		width: 100vw;
	}
	/*.swiper-pagination{
		width: 100vw;
		margin: 0 auto;
	}
	.swiper-pagination-bullet-active{
		background: #000;
	}
	.swiper-pagination-bullet{
		border-radius: 0 !important;	
		
	}*/
	
	.list-block .item-content{
		padding-left: 0;
	}
	.list-block .item-inner{
		padding-right: 0;
	}
	.list-block .item-title.label{
		width: 25%;
	}
	.list-block .list-button{
		color: #31B716;
	}
	.btn_yzm{
		position: absolute;
		width: 8rem;
		text-align: center;
		font-size: 1.5rem;
		color: #333;
		border: 0.1rem solid #666666;
		padding: 0.2rem 1rem;
		border-radius: 0.4rem;
		z-index: 2;
		right: 0;
		top: 0.8rem;
	}
	
	.loginCon{
		width: 80%;
		margin: 2rem 10% 0 10%;
		
	}
	.formList{
		position: relative;
		padding: 0.8rem 0;
		font-size: 4vw;
		line-height: 1.5;
		margin-top: 1.2rem;
	}
	.formList input{
		font-size: 4vw;
		line-height: 1.5;
		border: none;
		outline: none;
	}
	.formIn{
		display: block;
		color: #333;
		width:100%;
	}
	.yzmBtn{
		position: absolute;
		padding: 0 1.2rem;
		color: #4dbe56;
		float: right;
		text-align: center;
		right: 0;
		top: 0.8rem;
		z-index: 2;
	}
	.form_btn{
		width: 80%;
		height: 4.5rem;
		/*margin:2.5rem 0 0 10%;*/
		background: #4dbe56;
		color: #f2fff3;
		font-size: 1.6rem;
		text-align: center;
		line-height: 4.5rem;
		border-radius: 2.5rem;
		-webkit-border-radius: 2.5rem;
		-moz-border-radius: 2.5rem;
		box-shadow: 0 0.35rem 0 #248e2c;
		-webkit-box-shadow: 0 0.35rem 0 #248e2c;
		-moz-box-shadow: 0 0.35rem 0 #248e2c;
		letter-spacing: 0.1rem;
		cursor: pointer;
	}
	.form_btn:active{
		position: relative;
		top: 0.1rem;
	}
</style>