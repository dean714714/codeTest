<template>
	<div class="srBox">
		<div class="searchResult">
			<div class="searchResult_t">{{title}}</div>
			<div class="list-block">
			    <ul class="" v-show="searchDataSet.length>0&&searchDataSet?true:false">
			        <li class="item-content borderB" v-for="item in searchDataSet" @click="storeHistory(item.name,item[param]);$router.push({ path: searchUrl, query: { code: item[param],name: item.name}})">
			          <div class="item-media"><i class="iconfont icon-lishijilu"></i></div>
			          <div class="item-inner">
			            <div class="item-title">{{item.name}}</div>
			          </div>
			        </li>
			    </ul>
			    <div class="noHis" v-show="searchDataSet.length>0&&searchDataSet?false:true">
			    	<img src="../assets/img_search_defaul@2x.png" style="width: 40vw;margin: 2rem auto;"/>
			    	<div style="font-size: 4.5vw;text-align: center;margin-top: 5vw;color: #666;">无搜索结果~</div>
			    </div>
			</div>
		</div>
		<a href="#" class="button btn_rs" @click="showAll" v-show="btn_showAll_show">查看更多线路</a>
	</div>
</template>

<script>
	export default {
		name: 'searchResult2',
		props: ['items','searchUrl','param','title'],
		data() {
			return {
				searchData: [],
				btn_showAll_show: true,
				showAllList: false,
			}
		},
		computed: {
			tag:function(){//标记，表明是否需要截取显示
				if(this.searchData.length>5&&this.showAllList===false){
					return true;
				}else{
					return false;
				}
			},
			searchDataSet: function(){
				if(this.tag){
					return this.searchData.slice(0,5);
				}else{
					return this.searchData;
				}
			},
		},
		methods: {
			showAll: function(){
				this.showAllList = true;
				this.btn_showAll_show = false;
				//this.$emit('showAllData',true);
			},
			storeHistory: function(name,code){
				var local = JSON.parse(localStorage.getItem(this.param))||[];
				var obj = {},_this=this;
				obj.name = name;
				obj[this.param] = code;
				for(var i=0;i<local.length;i++){
					if(local[i][_this.param]*1===code*1)return;
				}
				if(local.length>=3){//删除最后一个记录
					local.splice(local.length-1,1);
				}
				local.unshift(obj);//添加一条新纪录
				localStorage.setItem(this.param,JSON.stringify(local));
				this.$emit("storeHis")
			},
		},
		watch: {
			items: function(data){
				this.searchData = data;
				this.showAllList = false;
				if(data.length>5){
					this.btn_showAll_show = true;
				}else{
					this.btn_showAll_show = false;
				}
			}
		}
		
	}
</script>

<style scoped>
	.srBox{
		background: #FFFFFF;
		padding: 2rem 0;
	}
	.searchResult{
		overflow: hidden;
		padding: 0 0 0 1.5rem ;
	}
	.searchResult_t{
		font-size: 1.4rem;
		color: #999999;
		margin-top: 1.5rem;
	}
	.list-block{
		margin: 0;
	}
	.list-block ul::before,.list-block ul::after{
		display: none;
	}
	.list-block .item-content{
		padding-left: 0;
	}
	.list-block .item-media + .item-inner{
		margin-left: 0.5rem;
	}
	.list-block .item-media{
		padding-top:0.2rem;
		padding-bottom: 0;
	}
	.list-block .item-media i{
		font-size: 1.4rem;
		line-height: 2.4rem;
		color: #666;
	}
	.list-block .item-title{
		color: #666;
		font-size: 1.4rem;
	}
	.btn_rs{
		border: 1px solid #4B4B4B;
		color: #333333;
		font-size: 1.4rem;
		width: 15rem;
		height: 3rem;
		margin:  3rem auto;
	}
	.button:not(.active).active-state {
		background: transparent;
	}
</style>