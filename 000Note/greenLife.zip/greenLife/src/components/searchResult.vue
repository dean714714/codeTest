<template>
	<div class="srBox">
		<div class="searchResult">
			<div class="searchResult_t">历史记录</div>
			<div class="list-block">
			    <ul v-show="historyList.length>0&&historyList?true:false">
			        <li class="item-content borderB" v-for="item in historyList" @click="storeHistory(item.name,item[param]);goNewPage(item)">
			          <div class="item-media"><i class="iconfont icon-lishijilu"></i></div>
			          <div class="item-inner">
			            <div class="item-title">{{item.name}}路</div>
			          </div>
			        </li>
			    </ul>
			    <div class="noHis" v-show="historyList.length>0&&historyList?false:true">
			    	<img src="../assets/img_search_defaul@2x.png" style="width: 40vw;margin: 2rem auto;"/>
			    	<div style="font-size: 4.5vw;text-align: center;margin-top: 5vw;color: #666;">无搜索结果~</div>
			    </div>
			</div>
		</div>
		<a href="#" class="button btn_rs" @click="clearHistory" v-show="historyList.length>0&&historyList?true:false">清空历史记录</a>
	</div>
</template>

<script>
	export default {
		name: 'searchResult',
		props: ['items','searchUrl','param'],
		data() {
			return {
				historyList: [],
			}
		},
		mounted: function(){
			console.log("这是公交历史纪录list组件")
		},
		methods: {
			clearHistory: function(){
				//这里还要写清空本地storage公交历史纪录的代码
				this.historyList=[];
				localStorage.removeItem(this.param);
				this.$emit("storeHis");
			},
			storeHistory: function(name,code){
				console.log("hello")
				var local = JSON.parse(localStorage.getItem(this.param))||[];
				var obj = {},_this=this;
				obj.name = name;
				obj[this.param] = code;
				for(var i=0;i<local.length;i++){
					if(local[i][_this.param]*1===code*1)return;
				}
				if(local.length>=3){//删除最后一个记录
					local.splice(local.length-1,1);
				}
				local.unshift(obj);//添加一条新纪录
				localStorage.setItem(this.param,JSON.stringify(local));
				//this.historyList = local||[];
				this.$emit("storeHis")
			},
			goNewPage: function(item){
				this.$router.push({ path: this.searchUrl, query: { code: item[this.param],name: item.name}})
			}
		},
		watch: {
			items: function(val){
				this.historyList = val||[];
			}
		}
		
	}
</script>

<style scoped>
	.srBox{
		background: #FFFFFF;
		padding: 2rem 0;
	}
	.searchResult{
		overflow: hidden;
		padding: 0 0 0 1.5rem ;
	}
	.searchResult_t{
		font-size: 1.4rem;
		color: #999999;
		margin-top: 1.5rem;
	}
	.list-block{
		margin: 0;
	}
	.list-block ul::before,.list-block ul::after{
		display: none;
	}
	.list-block .item-content{
		padding-left: 0;
	}
	.list-block .item-media + .item-inner{
		margin-left: 0.5rem;
	}
	.list-block .item-media{
		padding-top:0.2rem;
		padding-bottom: 0;
	}
	.list-block .item-media i{
		font-size: 1.4rem;
		line-height: 2.4rem;
		color: #666;
	}
	.list-block .item-title{
		color: #666;
		font-size: 1.4rem;
	}
	.btn_rs{
		border: 1px solid #4B4B4B;
		color: #333333;
		font-size: 1.4rem;
		width: 15rem;
		height: 3rem;
		margin:  3rem auto;
	}
	.button:not(.active).active-state {
		background: transparent;
	}
</style>